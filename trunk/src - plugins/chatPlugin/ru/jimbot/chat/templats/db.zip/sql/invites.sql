Begin Transaction;
Drop Table If Exists [invites];
CREATE TABLE IF NOT EXISTS  "invites"(
[id] INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL
,[user_id] int(11) DEFAULT NULL
,[time] text NOT NULL DEFAULT '0'
,[invite] varchar(20) DEFAULT NULL
,[new_user] int(11) DEFAULT NULL
,[create_time] text NOT NULL DEFAULT '0'
,[note] text 
);
Commit Transaction;    
