Begin Transaction;
Drop Table If Exists [events];
CREATE TABLE IF NOT EXISTS  "events"(
[id] INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL
,[time] text NOT NULL DEFAULT '0'
,[user_id] int(11) DEFAULT NULL
,[user_sn] varchar(50) DEFAULT NULL
,[type] varchar(10) DEFAULT NULL
,[user_id2] int(11) DEFAULT NULL
,[user_sn2] varchar(50) DEFAULT NULL
,[msg] text
);
Commit Transaction;    
