Begin Transaction;
Drop Table If Exists [rooms];
CREATE TABLE IF NOT EXISTS  "rooms"(
[id] INTEGER PRIMARY KEY NOT NULL
,[name] varchar(100) NOT NULL
,[topic] varchar(255) NOT NULL
,[pass] varchar(20) NOT NULL
,[user_id] int(11) NOT NULL
);
INSERT INTO `rooms` (`id`, `name`, `topic`, `pass`, `user_id`) VALUES (0, '�����', '', '', 0);
INSERT INTO `rooms` (`id`, `name`, `topic`, `pass`, `user_id`) VALUES (1, '��������� *WALL*', '', '', 0);
Commit Transaction;

