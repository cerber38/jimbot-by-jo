Begin Transaction;
Drop Table If Exists [users];
CREATE TABLE IF NOT EXISTS  "users"(
[id] INTEGER NOT NULL
,[sn] varchar(30) DEFAULT NULL
,[nick] varchar(255) DEFAULT NULL
,[localnick] varchar(255) DEFAULT NULL
,[fname] varchar(255) DEFAULT NULL
,[lname] varchar(255) DEFAULT NULL
,[email] varchar(255) DEFAULT NULL
,[city] varchar(255) DEFAULT NULL
,[homepage] varchar(255) DEFAULT NULL
,[gender] int(11) DEFAULT NULL
,[birthyear] int(11) DEFAULT NULL
,[birthmonth] int(11) DEFAULT NULL
,[birthday] int(11) DEFAULT NULL
,[age] int(11) DEFAULT NULL
,[country] int(11) DEFAULT NULL
,[language] int(11) DEFAULT NULL
,[state] int(11) DEFAULT NULL
,[basesn] varchar(30) DEFAULT NULL
,[createtime] text NOT NULL DEFAULT '0'
,[room] int(11) DEFAULT NULL
,[lastkick] text NOT NULL DEFAULT '0'
,[lbalans] int(11) DEFAULT NULL
,[balans] int(11) DEFAULT NULL
,[cena] int(11) DEFAULT NULL
,[dateb] text NOT NULL DEFAULT '0'
,[lastnick] varchar(255) DEFAULT NULL
,[pass] varchar(255) DEFAULT NULL
,[webpage] varchar(255) NOT NULL DEFAULT '���'
,[unicode] int(11) DEFAULT 0
);


Commit Transaction;
