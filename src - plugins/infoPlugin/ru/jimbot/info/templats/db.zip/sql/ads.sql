Begin Transaction;
Drop Table If Exists [ads];
CREATE TABLE IF NOT EXISTS  "ads"(
[id] INTEGER NOT NULL
,[txt] text NOT NULL
,[enable] int(1) NOT NULL DEFAULT '1'
,[note] text
,[client] text
,[expDate] text
,[maxCount] int(11) 
);
Commit Transaction;    
