Begin Transaction;
Drop Table If Exists [ads_log];
CREATE TABLE IF NOT EXISTS  "ads_log"(
[ads_id] int(11) NOT NULL
,[time] text NOT NULL DEFAULT '0'
,[uin] varchar(20) DEFAULT NULL
);
Commit Transaction;    
