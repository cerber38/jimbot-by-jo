Begin Transaction;
Drop Table If Exists [aneks_tmp];
CREATE TABLE IF NOT EXISTS  "aneks_tmp"(
[id] INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL
,[text] text
,[uin] varchar(20) DEFAULT NULL
);
Commit Transaction;    
